# discord-youtube-bot
**Discord'dan, YouTube kullanabileceğiniz bot kodları.**

> ## Kurulum
> **NodeJS** indirip ardından, bu videoyu https://youtu.be/_sFs5I3ZIQ0 izleyerek kurulumu gerçekleştirebilirsiniz.

> ## Credit
> **Kodları [buradan](https://github.com/Snowflake107/youtube-together-bot) aldım. Türkçeleştirerek, sadece YouTube özelliğini açmasını (normalde bir kaç oyun açıyor) sağladım.**
